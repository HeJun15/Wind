Elasticsearch Mapping library
=============================

Java library for Elasticsearch to migrate/create easily mappings of indexes.
