Demo code for manage data in ElasticSearch with Java Client
=======================
	- ElasticSearch 0.90.2
	
	
	'''
	<dependency>
		<groupId>org.elasticsearch</groupId>
		<artifactId>elasticsearch</artifactId>
		<version>0.90.2</version>
	</dependency>
	'''


