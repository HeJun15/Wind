es-showcase
===========

This is a demo application that showcases some of the features of the Elasticsearch Java API
