package cn.injava.es.spring.domain;

/**
 * Created by Green Lei on 2015/11/17 11:57.
 */
public class Tag {
    private String id;
    private String name;
    public String getId() {
        return id;
    }
    public void setId(String id) {
        this.id = id;
    }
    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }
}
