Elasticsearch Java Test Cases
=============================

This repository contains some test cases when asked by users on mailing list about Elasticsearch java usage.


Build Status
============

Thanks to cloudbees for the [build status](https://buildhive.cloudbees.com): [![Build Status](https://buildhive.cloudbees.com/job/elasticsearchfr/job/elasticsearch-java-tests/badge/icon)](https://buildhive.cloudbees.com/job/elasticsearchfr/job/elasticsearch-java-tests/)

[![Test trends](https://buildhive.cloudbees.com/job/elasticsearchfr/job/elasticsearch-java-tests/test/trend)](https://buildhive.cloudbees.com/job/elasticsearchfr/job/elasticsearch-java-tests/)

How to use it
=============

Download the project
--------------------

     git clone https://github.com/elasticsearchfr/elasticsearch-java-tests.git

Compile the project
-------------------

     mvn compile

Run tests
---------

     mvn test



