package org.elasticsearchfr.tests.bean;

public enum Colour {
	DARK,
	PALE,
	WHITE;
}
