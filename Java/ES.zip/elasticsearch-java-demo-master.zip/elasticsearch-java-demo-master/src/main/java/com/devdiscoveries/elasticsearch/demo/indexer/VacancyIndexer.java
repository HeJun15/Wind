package com.devdiscoveries.elasticsearch.demo.indexer;

import com.devdiscoveries.elasticsearch.demo.domain.Vacancy;

public class VacancyIndexer implements Indexer<Vacancy> {

    @Override
    public boolean indexDocument(Vacancy document) {
	// TODO Auto-generated method stub
	return false;
    }

    @Override
    public boolean createIndex() {
	// TODO Auto-generated method stub
	return false;
    }

    @Override
    public boolean upgradeIndex() {
	// TODO Auto-generated method stub
	return false;
    }

    @Override
    public boolean deleteDocument(Vacancy document) {
	// TODO Auto-generated method stub
	return false;
    }

}
