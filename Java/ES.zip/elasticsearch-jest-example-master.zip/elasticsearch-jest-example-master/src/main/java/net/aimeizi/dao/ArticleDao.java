package net.aimeizi.dao;

import net.aimeizi.model.Article;

/**
 * Created by Administrator on 2015/9/10.
 */
public interface ArticleDao {
    void save(Article article);
}
