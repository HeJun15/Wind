# Elasticsearch Java API demo

Basic examples of using Elasticsearch Java API. Implemented as a collection of unit tests.

[Authors](https://github.com/lukas-vlcek/elasticsearch.demo/contributors)