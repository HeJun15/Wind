ogc-tools
=========

WMS Server, projection and great circle navigation tools
