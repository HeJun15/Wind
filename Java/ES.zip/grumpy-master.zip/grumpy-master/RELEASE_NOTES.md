Release Notes
---------------
###Version 0.2 ([Maven Central](http://search.maven.org/#search%7Cga%7C1%7Cg%3A%22com.github.davidmoten%22))
* many breaking changes
* added builder for capabilities
* added ```Reducer`` to abstract reductionist drawing of regions
* refactored Darkness layer
* added grumpy-app artifact to offer Darkness layer in a war
* simplified Darkness layer

###Version 0.1  ([Maven Central](http://search.maven.org/#search%7Cga%7C1%7Cg%3A%22com.github.davidmoten%22))
* initial release
