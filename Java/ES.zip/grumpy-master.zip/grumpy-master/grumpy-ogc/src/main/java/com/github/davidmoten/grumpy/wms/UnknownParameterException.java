package com.github.davidmoten.grumpy.wms;

public class UnknownParameterException extends Exception {

    private static final long serialVersionUID = 4788825665080636000L;

    public UnknownParameterException(String message) {
        super(message);
    }

}
