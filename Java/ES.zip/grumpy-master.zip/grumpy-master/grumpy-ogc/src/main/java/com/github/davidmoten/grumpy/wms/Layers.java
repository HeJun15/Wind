package com.github.davidmoten.grumpy.wms;

public interface Layers {
    Layer getLayer(String layerName);
}
