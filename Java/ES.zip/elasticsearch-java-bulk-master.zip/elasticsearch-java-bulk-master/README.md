ElasticSearch Bulk Indexing - Java API
===============================

This is a simple sample application that uses ElasticSearch's Java API and Spring to connect to a running ElasticSearch instance and do a bulk index operation.
