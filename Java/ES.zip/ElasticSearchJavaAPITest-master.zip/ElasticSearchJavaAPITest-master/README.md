This repo gives an example on how to use the elasticsearch java api
