# elasticsearch-demo
Demoing REST implementation for ES indexing in Java
