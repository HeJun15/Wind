# elasticsearchexample
A simple java class to query an elastic search index
